import boto3 
import io

def lambda_handler(event, context):
     
    return {
            'statusCode': 200,
            'body': 'Hello Bro!!!'
        } 